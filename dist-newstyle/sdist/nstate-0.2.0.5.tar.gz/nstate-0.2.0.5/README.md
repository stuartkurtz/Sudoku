Control.Monad.NState
====================

Nondeterministic State Monad
